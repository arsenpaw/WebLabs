export default interface PrinterModel {
  name: string;
  pagePerMinute: number;
  imgUrl: string;
  cost: number;

}
